
public class InvalidListPositionException extends Exception
{
	public InvalidListPositionException()
	{
		super();
	}
	public InvalidListPositionException(String message)
	{
		super(message);
	}
}
